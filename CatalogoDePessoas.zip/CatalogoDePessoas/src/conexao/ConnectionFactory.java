/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import interfaces.Janela;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Andressa
 */
public class ConnectionFactory {
    public Connection getConnection(){
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost/cadastropessoas","root","");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível conectar.\n "+e);
            throw new RuntimeException(e);
        }
    }
}
