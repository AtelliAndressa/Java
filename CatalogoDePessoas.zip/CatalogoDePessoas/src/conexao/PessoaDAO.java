/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;
import classes.Pessoa;
import interfaces.Janela;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * Andressa
 */
public class PessoaDAO {
    
    public Connection conexao;
    
    public PessoaDAO(){
        this.conexao = new ConnectionFactory().getConnection();
        
        String sql = "create table if not exists pessoas (id int auto_increment primary key,"
                + "nome varchar(255), sexo varchar(255), dataNascimento date, "
                + "profissao varchar(255) NULL DEFAULT NULL, cpf varchar(255),"
                + "tipoSanguineo varchar(255) NULL DEFAULT NULL)";   
        try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            
            ps.execute();
            ps.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Enviar ao Banco de dados. \n"+e);
        }
        
        try {
            this.conexao.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Encerrar o Banco de Dados.\nContate o Administrador do Sistema. \n"+e);
        }
        
    
    }

    public void adicionar(Pessoa p1){
           this.conexao = new ConnectionFactory().getConnection();
           
           String sql = "insert into pessoas "
                   + "(nome,sexo,dataNascimento,profissao,cpf,tiposanguineo)"
                   + "values (?,?,?,?,?,?)";
           
           try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            
            ps.setString(1, p1.getNome());
            ps.setString(2, p1.getSexo());
            ps.setDate(3, new Date(p1.getDataNascimento().getTime()));
            ps.setString(4, p1.getProfissao());
            ps.setString(5, p1.getCpf());
            ps.setString(6, p1.getTipoSanguineo());
            
            
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(Janela.getInstance(), "O usuario "+p1.getNome()+" foi inserido com sucesso.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Inserir no BD.\n"+e);
        }
        try {
            this.conexao.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Encerrar o Banco de Dados.\nContate o Administrador do Sistema. \n"+e);
        }
    }
    
    public ArrayList<Pessoa> pesquisarNome(String nome){
            this.conexao = new ConnectionFactory().getConnection();
            ArrayList<Pessoa> listaPessoas = new ArrayList<Pessoa>();

            String sql = "select * from pessoas where nome like ?";

            try {
                PreparedStatement ps = conexao.prepareStatement(sql);
                ps.setString(1, nome+"%");
                
                ResultSet rs = ps.executeQuery();
                while(rs.next()){
                    Pessoa p1 = new Pessoa();
                    
                    p1.setId(rs.getInt("id"));
                    p1.setNome(rs.getString("nome"));
                    p1.setSexo(rs.getString("sexo"));
                    p1.setDataNascimento(rs.getDate("dataNascimento"));
                    p1.setProfissao(rs.getString("profissao"));
                    p1.setCpf(rs.getString("cpf"));
                    p1.setTipoSanguineo(rs.getString("tipoSanguineo"));
                    
                    listaPessoas.add(p1);
                }
                
                ps.execute();
                ps.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Pesquisar no BD.\n"+e);
            }
           
            try {
                this.conexao.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Encerrar o Banco de Dados.\nContate o Administrador do Sistema. \n"+e);
            }
            return listaPessoas;
    }

    
    public void remover(int id){
        this.conexao = new ConnectionFactory().getConnection();
           
           String sql = "delete from pessoas where id = ?";
           try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);
            
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(Janela.getInstance(), "Id: "+id+"Removido com Sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Remover no BD.\n"+e);

        }
        try {
             this.conexao.close();
         } catch (Exception e) {
             JOptionPane.showMessageDialog(Janela.getInstance(), "Não foi possível Encerrar o Banco de Dados.\nContate o Administrador do Sistema. \n"+e);
         }
    }
}

/*
int id;
    String nome;
    String sexo;
    Date dataNascimento;
    String profissao;
    String cpf;
    String tipoSanguineo;*/